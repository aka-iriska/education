# frozen_string_literal: true

require 'date'

# NOTE
class NotesController < ApplicationController
  before_action :check_for_cancel, only: %i[create update]
  before_action :set_note, only: %i[show edit update destroy]

  # GET /notes or /notes.json
  def index
    @notes = Note.all
  end

  # GET /notes/1 or /notes/1.json
  def show; end

  # GET /notes/new
  def new
    @note = Note.new
  end

  # GET /notes/1/edit
  def edit; end

  # POST /notes or /notes.json
  def create
    unless signed_in?
      respond_to do |format|
        format.html { redirect_to signin_path }
      end
      return
    end
    days = { 0 => 'Воскресенье',
             1 => 'Понедельник',
             2 => 'Вторник',
             3 => 'Среда',
             4 => 'Четверг',
             5 => 'Пятница',
             6 => 'Суббота' }
    msg_text = ''
    msg_status = :success
    params[:note][:User_id] = current_user.id
    day_date = params[:note][:day_date]
    params[:note][:week_day] = days[Date.strptime(day_date, '%Y-%m-%d').wday]
    params[:note][:time] = '' unless params[:note][:time]
    params[:note][:diary] = '' unless params[:note][:diary]
    params[:note][:info] = t('Нет информации') unless params[:note][:info]
    params[:note][:import] = false unless params[:note][:import]
    params[:note][:if_done] = false
    @note = Note.new(note_params)

    respond_to do |format|
      if @note
        pp 'check 3'
        if (msg_status == :success) && @note.save
          # menu_path @note
          msg_text = t('Запись была успешно создана')
          flash[msg_status] = msg_text
          format.html { redirect_to menu_path }
          format.json { render :show, status: :created, location: menu_path }
        else
          flash.now[msg_status] = msg_text
          format.html { render :new, status: :unprocessable_entity }
          format.json { render json: @user.errors, status: :unprocessable_entity }
        end
      end
    end
  end

  # PATCH/PUT /notes/1 or /notes/1.json
  def update
    pp 'update', params[:id], params[:if_done]
    respond_to do |format|
      if @note.update(note_params)
        Note.all.sort_by { |x| [x.User_id, x.day_date, x.time.empty? ? 1 : 0, x.time] }
        format.html { redirect_to '/main/menu' }
        # format.json { render :show, status: :ok, location: @note }
        format.js
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @note.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /notes/1 or /notes/1.json
  def destroy
    @note = Note.find(params[:id])
    @note.destroy!
    @notes = Note.all # обновляем список записей
    respond_to do |format|
      format.js
      format.html { redirect_to '/main/menu' }
      # format.json { head :no_content }
    end
  end

  # для кнопочки отмена записи
  def check_for_cancel
    return unless params[:commit] == t('Cancel')

    redirect_to menu_path
  end

  def update_checkbox_if_done
    id = params[:id] # предполагая, что id элемента передается в параметрах
    status = params[:if_done] # статус true/false из чекбокса
    # Здесь используйте вашу модель для обновления записи в базе данных
    @note = Note.find(id)
    if @note.update_attribute(:if_done, status)
      render json: { status: 'success' }
    else
      render json: { status: 'error' }
    end
  end
  def update_checkbox_import
    id = params[:id] # предполагая, что id элемента передается в параметрах
    status = params[:import] # статус true/false из чекбокса
    # Здесь используйте вашу модель для обновления записи в базе данных
    @note = Note.find(id)
    if @note.update_attribute(:import, status)
      render json: { status: 'success' }
    else
      render json: { status: 'error' }
    end
  end
  private

  # Use callbacks to share common setup or constraints between actions.
  def set_note
    @note = Note.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def note_params
    params.require(:note).permit(:day_date, :User_id, :time, :task, :week_day, :colour, :diary, :info, :import,
                                 :if_done)
  end
end
