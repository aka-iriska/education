
$(document).on('click', '.btn-close', function () {
    $('.alert').fadeOut();
});

//ФУНКЦИЯ ВЫВОДА СБОКУ
function show_result(data) {
    // document.getElementById("right").value='';
    console.log(data);
    const result = document.getElementById("right");
    result.innerHTML = "<div >" + data + "</div>";
    // Создать кнопку
    let newButton = document.createElement('button');
    newButton.classList.add('btn', 'btn-primary');
    newButton.textContent = Hide_Button;
    newButton.addEventListener('click', function () {
        document.getElementById('right').innerHTML = '';
        // Очищаем содержимое целевого элемента
    });
    // Добавить кнопку на страницу
    document.getElementById("right").appendChild(newButton);
}

$(document).ajaxSuccess(function (event, request, options, data) {
    console.log(options)
    let form_url = locale+options.url
    console.log('main_right_form success', data, 'form url', form_url);

    if (form_url.includes('main/adding/')) {
        show_result(data.value);
    }

});


