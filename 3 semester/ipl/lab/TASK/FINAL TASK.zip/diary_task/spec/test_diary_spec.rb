require 'rails_helper'
require "json"
require "selenium-webdriver"
require "rspec-rails"
include RSpec::Expectations

describe "NewNote" do

  before(:each) do
    @driver = Selenium::WebDriver.for :edge
    @base_url = "https://www.google.com/"
    @accept_next_alert = true
    @driver.manage.timeouts.implicit_wait = 30
    @verification_errors = []
  end

  after(:each) do
    @driver.quit
    @verification_errors.should == []
  end

  it "test_new_note" do
    @driver.get "http://127.0.0.1:3000/ru/signin"
    @driver.find_element(:id, "session_email").click
    @driver.find_element(:id, "session_email").clear
    @driver.find_element(:id, "session_email").send_keys "admin@gmail.com"
    @driver.find_element(:xpath, "//body").click
    @driver.find_element(:id, "session_password").click
    @driver.find_element(:id, "session_password").clear
    @driver.find_element(:id, "session_password").send_keys "12345"
    @driver.find_element(:xpath, "//body").click
    @driver.find_element(:name, "login_btn").click
    sleep 2.0
    @driver.get "http://127.0.0.1:3000/ru/menu"
    @driver.find_element(:link, "ДОБАВИТЬ").click
    @driver.get "http://127.0.0.1:3000/ru/adding"
    @driver.find_element(:id, "note_day_date").click
    @driver.find_element(:id, "note_day_date").clear
    @driver.find_element(:id, "note_day_date").send_keys "0002-12-12"
    @driver.find_element(:id, "note_day_date").clear
    @driver.find_element(:id, "note_day_date").send_keys "0020-12-12"
    @driver.find_element(:id, "note_day_date").clear
    @driver.find_element(:id, "note_day_date").send_keys "0200-12-12"
    @driver.find_element(:id, "note_day_date").clear
    @driver.find_element(:id, "note_day_date").send_keys "2002-12-12"
    @driver.find_element(:id, "note_task").click
    @driver.find_element(:id, "note_task").clear
    @driver.find_element(:id, "note_task").send_keys "test"
    @driver.find_element(:xpath, "//form[@id='add_new_task']/div[7]/input[2]").click
  end

  def element_present?(how, what)
    @driver.find_element(how, what)
    true
  rescue Selenium::WebDriver::Error::NoSuchElementError
    false
  end

  def alert_present?()
    @driver.switch_to.alert
    true
  rescue Selenium::WebDriver::Error::NoAlertPresentError
    false
  end

  def verify(&blk)
    yield
  rescue ExpectationNotMetError => ex
    @verification_errors << ex
  end

  def close_alert_and_get_its_text(how, what)
    alert = @driver.switch_to().alert()
    alert_text = alert.text
    if (@accept_next_alert) then
      alert.accept()
    else
      alert.dismiss()
    end
    alert_text
  ensure
    @accept_next_alert = true
  end
end


describe "NewDiary" do

  before(:each) do
    @driver = Selenium::WebDriver.for :edge
    @base_url = "https://www.google.com/"
    @accept_next_alert = true
    @driver.manage.timeouts.implicit_wait = 30
    @verification_errors = []
  end

  after(:each) do
    @driver.quit
    @verification_errors.should == []
  end

  it "test_new_diary" do
    @driver.get "http://127.0.0.1:3000/ru/signin"
    @driver.find_element(:id, "session_email").click
    @driver.find_element(:id, "session_email").clear
    @driver.find_element(:id, "session_email").send_keys "admin@gmail.com"
    @driver.find_element(:xpath, "//body").click
    @driver.find_element(:id, "session_password").click
    @driver.find_element(:id, "session_password").clear
    @driver.find_element(:id, "session_password").send_keys "12345"
    @driver.find_element(:xpath, "//body").click
    @driver.find_element(:name, "login_btn").click
    sleep 2.0
    @driver.get "http://127.0.0.1:3000/ru/menu"
    sleep 2.0
    @driver.find_element(:name, "diary_button").click
    sleep 2.0
    #@driver.find_element(:xpath, "//div[@id='dModal90']/div/div/div[2]").click
    @driver.find_element(:id, "note_diary").clear
    @driver.find_element(:id, "note_diary").send_keys "привет ещё раз"
    sleep 2.0
    @driver.find_element(:name, "ChangeDiary_button").click
    sleep 2.0
  end

  def element_present?(how, what)
    @driver.find_element(how, what)
    true
  rescue Selenium::WebDriver::Error::NoSuchElementError
    false
  end

  def alert_present?()
    @driver.switch_to.alert
    true
  rescue Selenium::WebDriver::Error::NoAlertPresentError
    false
  end

  def verify(&blk)
    yield
  rescue ExpectationNotMetError => ex
    @verification_errors << ex
  end

  def close_alert_and_get_its_text(how, what)
    alert = @driver.switch_to().alert()
    alert_text = alert.text
    if (@accept_next_alert) then
      alert.accept()
    else
      alert.dismiss()
    end
    alert_text
  ensure
    @accept_next_alert = true
  end
end
describe "CheckboxAndChangeNote" do

  before(:each) do
    @driver = Selenium::WebDriver.for :edge
    @base_url = "https://www.google.com/"
    @accept_next_alert = true
    @driver.manage.timeouts.implicit_wait = 30
    @verification_errors = []
  end

  after(:each) do
    @driver.quit
    @verification_errors.should == []
  end

  it "test_checkbox_and_change_note" do
    @driver.get "http://127.0.0.1:3000/ru/signin"
    @driver.find_element(:id, "session_email").click
    @driver.find_element(:id, "session_email").clear
    @driver.find_element(:id, "session_email").send_keys "admin@gmail.com"
    @driver.find_element(:xpath, "//body").click
    @driver.find_element(:id, "session_password").click
    @driver.find_element(:id, "session_password").clear
    @driver.find_element(:id, "session_password").send_keys "12345"
    @driver.find_element(:xpath, "//body").click
    @driver.find_element(:name, "login_btn").click
    sleep 2.0
    @driver.get "http://127.0.0.1:3000/ru/menu"
    @driver.find_element(:name, "checkbox_for_note").click
    sleep 2.0
    @driver.find_element(:name, "checkbox_for_note").click
    sleep 2.0
    @driver.find_element(:name, "menu_change_note_btn").click
    @driver.find_element(:name, "note[colour]").click
    @driver.find_element(:name, "note[colour]").clear
    @driver.find_element(:name, "note[colour]").send_keys "#9cce69"
    sleep 2.0
    @driver.find_element(:name, "note[info]").clear
    sleep 2.0
    @driver.find_element(:name, "note[info]").send_keys "new test"
    sleep 2.0
    @driver.find_element(:name, "commit").click
    sleep 2.0
  end

  def element_present?(how, what)
    @driver.find_element(how, what)
    true
  rescue Selenium::WebDriver::Error::NoSuchElementError
    false
  end

  def alert_present?()
    @driver.switch_to.alert
    true
  rescue Selenium::WebDriver::Error::NoAlertPresentError
    false
  end

  def verify(&blk)
    yield
  rescue ExpectationNotMetError => ex
    @verification_errors << ex
  end

  def close_alert_and_get_its_text(how, what)
    alert = @driver.switch_to().alert()
    alert_text = alert.text
    if (@accept_next_alert) then
      alert.accept()
    else
      alert.dismiss()
    end
    alert_text
  ensure
    @accept_next_alert = true
  end
end
