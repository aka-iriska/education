require "test_helper"
# rake test:integration
# rake test TEST=test/integration/authentication_pages_test.rb
class AuthenticationPagesTest < ActionDispatch::IntegrationTest
  def user_params(name, email, password)
    { 'name' => name, 'email' => email, 'password' => password, 'password_confirmation' => password, 'admin' => false }
  end

  def add_record(name, email, password)
    record = User.new(user_params(name, email, password))
    record.save
    record
  end

  # тест,позволяющий проверить регистрацию нового пользователя,
  # вход под его именем и выполнение вычислений
  ################################## Sign up ######################################
  # Проверяем доступность страницы регистрации
  test "test registration page access" do
    get signup_url
    assert_response :success
  end
  # Проверяем, что нельзя зарегестрировать того же пользователя
  test 'attempt to register with existing user details' do
    # Создаем пользователя
    add_record('test', 'test@test.com', '123456')
    get signup_url
    assert_response :success
    post users_url, params: { 'authenticity_token' => 'token',
                              'user' => { 'name' => 'test',
                                          'email' => 'test@test.com',
                                          'password' => '123456',
                                          'password_confirmation' => '123456' } }
    assert_response 422
  end
  # Проверяем, что пользователя можно зарегестрировать
  test 'successfully user registration' do
    get signup_url
    assert_response :success
    # Смотрим, что такой пользователь только 1
    assert_difference 'User.count', 1 do
      post users_url, params: { 'authenticity_token' => 'token',
                                'user' => { 'name' => 'test',
                                            'email' => 'test@test.com',
                                            'password' => '123456',
                                            'password_confirmation' => '123456' } }
      follow_redirect!
    end
    assert_template 'main/menu'
    assert_response 200
  end
  ################################## Sign in ######################################
  # Проверяем доступность страницы входа
  test "test login page access" do
    get signin_url
    assert_response :success
  end

  test 'successfully user login' do
    add_record('test', 'test@test.com', '123456')
    assert_difference 'User.count', 0 do
      post sessions_url, params: { 'authenticity_token' => 'token',
                                   "session" => { "name" => 'test',
                                                  "email" => "test@test.com",
                                                  "password" => "123456" } }
      follow_redirect!
    end
    assert_template 'main/menu'
    assert_response 200
  end
  test 'login of a non-existent user' do
    post sessions_url, params: { 'authenticity_token' => 'token',
                                 "session" => { "name" => 'test',
                                                "email" => "test@test.com",
                                                "password" => "123456" } }
    assert_template 'sessions/new'
    assert_response 422
  end
  test 'login without password' do
    post sessions_url, params: { 'authenticity_token' => 'token',
                                 "session" => { "name" => 'test',
                                                "email" => "test@test.com",
                                                "password" => "" } }
    assert_template 'sessions/new'
    assert_response 422
  end

  ################################## Sign out ######################################
  test "test logout success" do
    # Добавляем тестового юзера в БД
    add_record('test', 'test@test.com', '123456')
    assert_difference 'User.count', 0 do
      # login
      post sessions_url, params: { 'authenticity_token' => 'token',
                                   "session" => { "name" => 'test',
                                                  "email" => "test@test.com",
                                                  "password" => "123456" } }
      follow_redirect!
    end
    assert_difference 'User.count', 0 do
      # Logout
      delete signout_url
      follow_redirect! # перенаправлены в menu, там проверочка, что не залогинились и идем в login
      follow_redirect! # из menu в login
    end
    assert_template 'sessions/new'
    assert_response 200
  end
  # Подготовить интеграционный тест для проверки невозможности
  # выполнения вычислений без ввода логина/пароля
  test "Post is impossible without sign in" do
    post notes_url, params: { 'authenticity_token' => 'test',
                             'test_note' => {
                               'day_date' => '2012-12-12',
                               'User_id' => 1,
                               'time' => '4:19',
                               'task' => 'write',
                               'week_day' => 'Понедельник',
                               'colour' => '#00000',
                               'diary' => 'sick',
                               'info' => 'no',
                               'import' => false,
                               'if_done' => false },
                             'locale' => 'en' }
    follow_redirect!
    # Если не вошли, значит редиректимся в signin
    assert_response 200
    assert_template 'sessions/new'
  end
end
