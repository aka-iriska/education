require "test_helper"
# rake test TEST=test/controllers/main_controller_test.rb - запуск теста
class MainControllerTest < ActionDispatch::IntegrationTest
  test "should get menu" do
    get menu_url
    assert_response 302 #так как не вошли
  end

  test "should get settings" do
    get settings_url
    assert_response :success
  end
end
