require "test_helper"
# rake test TEST=test/controllers/notes_controller_test.rb - запуск теста
class NotesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @user = User.new(id:1, email: 'test1@gmail.com', password: '123456', password_confirmation: '123456', remember_token: 'test_token', admin: false)
    @user.save
    @test_note1 = Note.new(day_date: '2012-12-12',
                           User_id:1,
                     time: '4:19',
                     task: 'write',
                     week_day: 'Понедельник',
                     colour: '#00000',
                     diary: 'sick',
                     info: 'no',
                     import: false,
                     if_done: false)
    @test_note1.save
    @test_note2 = { day_date: '2012-12-13',
                    User_id:1,
                    time: '4:20',
                    task: 'finish',
                    week_day: 'Понедельник',
                    colour: '#00000',
                    diary: 'tired',
                    info: 'no',
                    import: false,
                    if_done: false}
  end
  def user_params(email, password)
    { 'email' => email, 'password' => password, 'password_confirmation' => password, 'admin' => false }
  end

  def add_record(email, password)
    record = User.new(user_params(email, password))
    record.save
    record
  end
  test "should get index" do
    get notes_url
    assert_response :success
  end

  test "should get new" do
    get new_note_url
    assert_response :success
  end

  test "should create note" do
    #регистрация
    add_record('test@test.com', '123456')

    assert_difference 'User.count', 0 do
      post sessions_url, params: { 'authenticity_token' => 'token', 'session' => { 'email' => 'test@test.com', 'password' => '123456' } }
      follow_redirect!
    end
    #проверка перенаправления
    assert_template 'main/menu'
    assert_response 200
    assert_difference("Note.count") do
      post notes_url, params: { note: @test_note2 }
    end

    assert_redirected_to menu_path
  end

  test "should show note" do
    get note_url(locale='en',@test_note1)
    assert_response :success
  end

  test "should get edit" do
    get edit_note_url(locale='en',@test_note1)
    assert_response :success
  end

  test "should update note" do
    patch note_url(locale='en',@test_note1), params: { note: @test_note2 }
    assert_redirected_to '/main/menu'
  end

  test "should destroy note" do
    assert_difference("Note.count", -1) do
      delete note_url(locale='en', @test_note1)
    end

    assert_redirected_to '/main/menu'
  end
end
