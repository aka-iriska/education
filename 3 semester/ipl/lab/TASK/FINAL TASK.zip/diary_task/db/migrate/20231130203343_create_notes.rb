class CreateNotes < ActiveRecord::Migration[7.1]
  def change
    create_table :notes do |t|
      t.references :User, null: false, foreign_key: true
      t.date :day_date
      t.string :time
      t.string :task
      t.string :week_day
      t.string :colour

      t.timestamps
    end
  end
end
