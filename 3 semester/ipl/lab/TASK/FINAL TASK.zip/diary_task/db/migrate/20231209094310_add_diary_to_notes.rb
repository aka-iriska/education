class AddDiaryToNotes < ActiveRecord::Migration[7.1]
  def change
    add_column :notes, :diary, :text
    add_column :notes, :add_info_to_notes, :string
    add_column :notes, :info, :text
  end
end
