class AddIfDoneToNotes < ActiveRecord::Migration[7.1]
  def change
    add_column :notes, :if_done, :boolean
  end
end
