class AddImportToNotes < ActiveRecord::Migration[7.1]
  def change
    add_column :notes, :import, :boolean
  end
end
