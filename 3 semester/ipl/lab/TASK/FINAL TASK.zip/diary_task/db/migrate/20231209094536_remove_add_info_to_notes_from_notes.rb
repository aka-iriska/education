class RemoveAddInfoToNotesFromNotes < ActiveRecord::Migration[7.1]
  def change
    remove_column :notes, :add_info_to_notes, :text
  end
end
