Rails.application.routes.draw do
  scope "(:locale)", locale: /en|ru/ do
    resources :notes
    resources :users
    resources :sessions, :only => [:new, :create, :destroy]
    match '/menu', to: 'main#menu', via: 'get'
    match '/settings', to: 'main#settings', via: 'get'
    match '/main/adding/:id', to: 'main#adding', via: 'get'
    match '/main/diary/:id', to: 'main#diary', via: 'get'
    match '/notes/update_checkbox_if_done/:id', to: 'notes#update_checkbox_if_done', via: 'patch'
    match '/notes/update_checkbox_import/:id', to: 'notes#update_checkbox_import', via: 'patch'
    match '/adding', to: 'notes#new', via: [:get, :post]
    match '/signup', to: 'users#new', via: 'get'
    match '/signin', to: 'sessions#new', via: 'get'
    match '/set_locale', to: 'application#set_locale', via: 'get'
    match '/signout', to: 'sessions#destroy', via: 'delete'
    get "up" => "rails/health#show", as: :rails_health_check
    delete '/notes/:id' => 'notes#destroy'
    root 'main#menu'
  end
end
