# frozen_string_literal: true

# rubocop:disable Metrics/AbcSize
#rubocop:disable Metrics/MethodLength:

# Контроллер
class ChislaController < ApplicationController
  def input; end

  def view
    @input = ''
    @former = ''
    begin
      @input = params[:mass]
      res = params[:mass].scan(/-?\d+(?:\.\d+)?/).map(&:to_f)
      number = params[:chislo].to_i
      raise StandardError if res == [] || number > res.length

      res_array = find(res, number)
      @former = res_array[0]
      @result = res_array[1]
    rescue StandardError
      @result = 'Неверный формат'
    end
  end

  def find(string, mesto)
    res = string.dup
    ind_min = -1
    ind_max = -1
    minimum = 10_000_000.0
    maximum = -1_000_000.0
    res.length.times do |i|
      if res[i] > maximum
        maximum = res[i]
        ind_max = i
      end
      if res[i] < minimum
        minimum = res[i]
        ind_min = i
      end
    end
    pp ind_min
    pp ind_max
    summa = res[ind_min] + res[ind_max]
    c = res[ind_min]
    res[ind_min] = "<i>#{res[ind_max]}</i>"
    res[ind_max] = "<i>#{c}</i>"
    res[mesto] = "<b>#{summa}</b>"
    final_res = res.join('; ')
    ["<br/> Изначальный: <br/>#{string.join('; ')}<br/>",
     final_res]
  end
end
# rubocop:enable Metrics/AbcSize
