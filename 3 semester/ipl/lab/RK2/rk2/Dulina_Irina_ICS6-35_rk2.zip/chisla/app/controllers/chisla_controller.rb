# frozen_string_literal: true

# Контроллер
class ChislaController < ApplicationController
  def input; end

  def view
    @input = ''
    @former = ''
    begin
      @input = params[:mass]
      res = params[:mass].scan(/-?\d+(?:\.\d+)?/).map(&:to_f)
      raise StandardError if res == []

      res_array = find(res)
      @former = res_array[0]
      @result = res_array[1]
    rescue StandardError
      @result = 'Неверный формат'
    end
  end

  def find(string)
    res = string.dup
    count = 0 # количество кратных
    replace_ind = 0
    res.each_with_index do |elem, ind|
      count += 1 if (elem % 5).zero? && (elem % 3).zero?
      replace_ind = ind if (ind % 4).zero?
    end
    # res[ind_min] = "<i>#{res[ind_max]}</i>"
    # res[ind_max] = "<i>#{c}</i>"
    res[replace_ind] = "<b>#{count}</b>"
    final_res = res.join('; ')
    ["<br/> Изначальный: <br/>#{string.join('; ')}<br/>",
     final_res]
  end
end
