# frozen_string_literal: true

def find(res)
  proiz = 1
  ind = -1
  final_res = ''
  #if res.all?(&:numeric?)==false then pp 'ROLLBACK' end
  if res.any?(&:negative?) == true then
    res.length.times do |i|
      if res[i] < 0 then
        proiz = proiz * res[i]
      end
      if i % 3 == 0 then
        ind = i
      end
    end

    if ind != -1 then
      res[ind] = proiz
      final_res = res.join(' ')
    end
  else
    final_res = 'Отрицательных элементов нет. <br/>  Без изменений.<br/>' + res.join(' ')
  end
  final_res
end

pp 'Введите массив'
res=gets.chomp

pp find(res.split.map(&:to_f))