class ChislaResult < ApplicationRecord
end
