require "test_helper"

class ChislaResultTest < ActiveSupport::TestCase
  # test/fixures/ ..rb какой-то файл с кешом который хранит данные из пред бд, удалить

end

