$(document).on('click', '.btn-close', function () {
    $('.alert').fadeOut();
});