# frozen_string_literal: true

def prov(str)
  str == str.reverse
end
