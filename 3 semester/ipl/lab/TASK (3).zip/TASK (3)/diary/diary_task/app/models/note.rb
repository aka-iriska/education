class Note < ApplicationRecord
  belongs_to :User
end
