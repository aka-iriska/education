require './app/controllers/notes_controller'
class UsersController < ApplicationController
  before_action :set_user, only: %i[ show edit update destroy ]
  include NotesHelper
  # GET /users or /users.json
  def index
    @users = User.all
    #added
    @user_name = current_user ? current_user.name : "unknown"
  end

  # GET /users/1 or /users/1.json
  def show
  end

  # GET /users/new
  def new
    @user = User.new
  end

  # GET /users/1/edit
  def edit
  end

  # POST /users or /users.json
  def create
    #added
    msg_text = ''
    msg_status = :success

    email = params[:user][:email]
    password = params[:user][:password]
    password_confirmation = params[:user][:password_confirmation]
    params[:user][:admin]=false
    puts password

    @user = User.new(user_params)
    pp 'check 2'
    respond_to do |format|

      if @user
        if User.find_by_email(email)
          msg_text = 'Пользователь уже зарегестрирован!'
          msg_status = :danger
        elsif password != password_confirmation
          msg_text = 'Пароль для подтверждения введен неверно'
          msg_status = :danger
        elsif !email.match?('[a-z0-9]+[_a-z0-9\.-]*[a-z0-9]+@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})')
          msg_text = 'Введите почту корректно'
          msg_status = :danger
        end
        pp 'check 3'
        if msg_status == :success and @user.save
          sign_in @user
          msg_text = 'Спасибо за регистрацию'
          flash[msg_status] = msg_text

          format.html { redirect_to menu_path, notice: 'User was successfully created.' }
          format.json { render :show, status: :created, location: menu_path }
        else
          flash.now[msg_status] = msg_text
          format.html { render :new, status: :unprocessable_entity }
          format.json { render json: @user.errors, status: :unprocessable_entity }
        end
      end
    end
  end

  # PATCH/PUT /users/1 or /users/1.json
  def update
    respond_to do |format|
      if @user.update(user_params)
        format.html { redirect_to user_url(@user), notice: "User was successfully updated." }
        format.json { render :show, status: :ok, location: @user }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /users/1 or /users/1.json
  def destroy

    #удаление из notes сначала
    destroy_User_id(@user.id)
    @user.destroy!

    respond_to do |format|
      format.html { redirect_to users_url, notice: "User was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_user
      @user = User.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def user_params
      params.require(:user).permit(:name, :email, :password, :password_confirmation, :admin)
    end
end
