class MainController < ApplicationController
  def menu
    unless signed_in?
      redirect_to signin_path
    end

    @result = html_creation
    respond_to do |f|
      f.html
      f.json do
        render json: { type: @result.class.to_s, value: @result }
      end
    end
  end

  def html_creation
    notes = sort_notes
    current_date = '12345'
    result = ''
    output_begin = ''
    output_end = ''
    notes.each do |note|
      @note = note
      if @current_user && note.User_id == @current_user.id
        month_trans = I18n.t(note.day_date.strftime("%B"))
        if note.day_date != current_date
          result += output_begin + output_end
          output_begin, output_end = add_card('', '', note.day_date.strftime("%d #{month_trans}, %Y"), note.week_day)
          current_date = note.day_date
        end
        output_begin += add_task
      end
    end
    result += output_begin + output_end
    result
  end

  def add_task
    # Путь к файлу шаблона
    template_path = Rails.root.join('app', 'views', 'layouts', '_each_note.html.erb')

    # Считываем содержимое файла
    template_content = File.read(template_path)

    # Заменяем переменную в шаблоне
    ERB.new(template_content).result(binding)
  end

  def add_card(output_begin, output_end, day_date, week_day)

    output_begin += "<div class=\"card rounded border-0 shadow-sm position-relative\">
<div class=\"card-body p-5\">
<div class=\"align-items-center mb-4 pb-4 border-bottom\">
<i class=\"far fa-calendar-alt fa-3x\"></i>
<div class=\"ms-3\">
<h4 class=\"text-uppercase fw-weight-bold mb-0\">#{day_date}
<a class=\"btn btn-outline-primary float-end\"
   data-bs-toggle=\"modal\"
   data-bs-target=\"#dModal#{@note.id}\"
  href=\"/main/diary/#{@note.id}\"
  role=\"button\">#{t("DIARY")}</a></h4>"
    # Путь к файлу шаблона
    template_path = Rails.root.join('app', 'views', 'layouts', '_each_diary.html.erb')

    # Считываем содержимое файла
    template_content = File.read(template_path)

    # Заменяем переменную в шаблоне
    output_begin += ERB.new(template_content).result(binding)
    output_begin += "<p class=\"text-gray fst-italic mb-0\">#{week_day}</p></div></div>"
    output_end += "</div></div>"
    [output_begin, output_end]
  end

  def sort_notes
    Note.all.sort_by { |x| [x.User_id, x.day_date, x.time.empty? ? 1 : 0, x.time] }
  end

  # ФУНКЦИИ ДОБАВЛЕНИЯ ИНФОРМАЦИИ СПРАВА
  def adding
    unless signed_in?
      redirect_to signin_path
    end
    @add_right = task_info
    respond_to do |f|
      f.html
      f.json do
        render json: { type: @add_right.class.to_s, value: @add_right }
      end
    end
  end

  def task_info
    pp 'params id', params[:id]
    @note = Note.find_by_id(params[:id])
    pp "note", @note.info
    "<p>Подробная информация: </p><div >" + @note.info + "</div>"
  end
  def diary

  end
  def calendar
  end

  def settings
  end

end
