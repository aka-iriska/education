
$(document).on('click', '.btn-close', function () {
    $('.alert').fadeOut();
});

//ФУНКЦИЯ ВЫВОДА СБОКУ
function show_result(data) {
    // document.getElementById("right").value='';
    console.log(data);
    const result = document.getElementById("right");
    result.innerHTML = "<div >" + data + "</div>";
    // Создать кнопку
    let newButton = document.createElement('button');
    newButton.classList.add('btn', 'btn-primary');
    newButton.textContent = 'Скрыть';
    newButton.addEventListener('click', function () {
        document.getElementById('right').innerHTML = '';
        // Очищаем содержимое целевого элемента
    });
    // Добавить кнопку на страницу
    document.getElementById("right").appendChild(newButton);
}

$(document).ajaxSuccess(function (event, request, options, data) {
    let form_url = options.url
    console.log('main_right_form success', data, 'form url', form_url);

    if (form_url.includes('main/adding/')) {
        show_result(data.value);
    }
});
$(document).on('click', '#themeButton', function () {
    let theme = localStorage.getItem('theme');
    console.log('before check', theme);
    if (theme === 'dark') {
        theme = 'light';
        console.log('change to', theme);
        $('.btn-dark').removeClass('btn-dark').addClass('btn-primary');
    } else {
        theme = 'dark';
        console.log('change to', theme);
        $('.btn-primary').removeClass('btn-primary').addClass('btn-dark');
    }
    console.log('settheme', theme);
    localStorage.setItem('theme', theme);
});
window.onload = (event) => {
    const theme = localStorage.getItem('theme');
    console.log('window1', theme);
    if (!theme) {
        localStorage.setItem('theme', 'light');
        console.log('Default theme set to dark');
    } else {
        if (theme === 'dark') {
            $('.btn-primary').removeClass('btn-primary').addClass('btn-dark');
            console.log('window2', theme);
        } else {
            $('.btn-dark').removeClass('btn-dark').addClass('btn-primary');
            console.log('window2', theme);
        }
    }
};

