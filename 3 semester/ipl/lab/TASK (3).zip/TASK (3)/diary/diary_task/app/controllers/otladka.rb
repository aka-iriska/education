require 'D:\education\3 semester\ipl\lab\TASK\diary\diary_task\app\controllers\define_func.rb'
require 'date'
days = {0 => "ВС",
        1 => "ПН",
        2 => "ВТ",
        3 => "СР",
        4 => "ЧТ",
        5 => "ПТ",
        6 => "СБ"}
s='2023-12-02'
d=Date.strptime(s, "%Y-%m-%d")
#d=Date.parse( s.gsub(/, */, '-') )
puts "It's #{days[d.wday]}"