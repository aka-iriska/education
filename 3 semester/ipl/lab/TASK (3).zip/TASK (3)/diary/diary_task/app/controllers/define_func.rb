def define_week_day(day_date)
  code=arifm_week_day(day_date)
  case code
  when 0
    "Cб"
  when 1
    "Вс"
  when 2
    "Пн"
  when 3
    "Вт"
  when 4
    "Cр"
  when 5
    "Чт"
  when 6
    "Пт"
  else null
  end
end
def arifm_week_day(day_date)
  array = day_date.split("-")
  year = array[0]
  #если год висок, то номер месяца+2
  # если нет, то номер месяца+1
  if year.to_i%4==0
    month=array[1].to_i+2
  else month=array[1].to_i+1
  end
  day = array[2].to_i
  c=year[0,2].to_i
  d=year[2,4].to_i
  w=(13*(month+1))/5
  x=d+(d/4)
  y=c/4
  z=w+x+y+day+c-2*c
  z % 7
end