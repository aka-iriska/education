module NotesHelper
  def destroy_User_id(_user_id)
    while @note=Note.find_by(User_id: _user_id)
      @note.destroy!
    end
  end
end
