# README
```shell
rails new diary_task
cd diary_task
rails generate controller Main menu adding calendar settings
rails generate scaffold User name:string email:string:uniq password_digest:string remember_token:string:index admin:boolean
```


Для удаления модели используем:
```shell
rails destroy scaffold User
```

Для удаления поля используем:
```ruby
rails generate migration remove_<ПОЛЕ>_from_<ТАБЛИЦА> ПОЛЕ:ТИП
```


Пример:
```ruby
rails generate migration remove_password_from_user password:text
```



Для того чтобы получить прохождение этого теста мы вначале генерируем соответствующую миграцию для столбца
password_digest:

```shell
rails generate migration add_password_digest_to_users password_digest:string
rake db:create
rake db:migrate
rake db:migrate RAILS_ENV=test
```
## генерим контроллер sessions
```shell
rails generate controller Sessions --no-test-framework
```
## генерим бд для записей:
```shell
rails g scaffold Note User:references day_date:date time:string task:string weekday:string colour:string
rake db:migrate
rake db:migrate RAILS_ENV=test
```
## Ставим `bootstrap` и jquery
В `Gemfile`:

```ruby
gem "jquery-rails"
gem "bootstrap"
gem "sassc-rails"
```

Создадим папку `app/javascript/src`, а в ней наш `.js`
```js
$(document).on('click', '.btn-close', function () {
    $('.alert').fadeOut();
});

```

В `config/initializers/assets.rb`:

```ruby
Rails.application.config.assets.precompile +=
  %w( jquery.min.js jquery_ujs.js bootstrap.min.js popper.js moment-with-locales.min.js bootstrap-datetimepicker.min.js)
```

В `app/assets/stylesheets/application.scss` (обратите внимание, что суффикс файла должен быть `.scss`, а не `.css`, при
необходимости измените суффикс):

```ruby
@import "bootstrap";
```

В `config/importmap.rb`:

```ruby
pin_all_from 'app/javascript/src', under: 'src'
pin "jquery", to: "jquery.min.js", preload: true
pin "jquery_ujs", to: "jquery_ujs.js", preload: true
pin "popper", to: "popper.js", preload: true
pin "bootstrap", to: "bootstrap.min.js", preload: true
```

В `app/javascript/application.js`:

```ruby
import "jquery"
import "jquery_ujs"
import "popper"
import "bootstrap"
import "src/main"
```
## код скопипащен из 12 лабы по:
`app/controllers/application_controller.rb`
`app/controllers/sessions_controller.rb`
`app/controllers/users_controller.rb`
`app/helpers/sessions_helper.rb `
`app/javascript/src/main.js `
+пресдтавления (немного из 12 лабы Ильи, где нужно подтверждение пароля и залупа с didgest и токеном)
## `app/models/user.rb`
Добавим возможность использовать `authenticate` и шифрование пароля в
модель `app/models/user.rb`
(Валидации наличия и подтверждения автоматически добавляются
has_secure_password):
```ruby
before_save { self.email = email.downcase }
  before_create :create_remember_token

  VALID_EMAIL_REGEX = /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/i
  has_secure_password
  validates :email, presence:   true,
            format:     { with: VALID_EMAIL_REGEX },
            uniqueness: { case_sensitive: false }
  validates :password, length: { minimum: 4 }

  def User.new_remember_token
    SecureRandom.urlsafe_base64
  end

  def User.encrypt(token)
    Digest::SHA1.hexdigest(token.to_s)
  end

  private

  def create_remember_token
    self.remember_token = User.encrypt(User.new_remember_token)
  end
```
## добавление админа
```sql
insert into users(name, email, password_digest, remember_token, created_at, updated_at, admin)
VALUES ('me','admin@email.com', '$2a$12$fPPfThxkvqZwkVqpNbc3u.ehzJv6v3NanqPkzQyPK5TiCx3vr/joO',
        'b95a184d03b82f167ef75d6668096eb1e6dd4d2a', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, true);
select * from users;
```
## в моём `main_controller`
НЕ ЗАБЫТЬ ПРОВЕРКУ НА ВХОД:
```ruby
def input
  unless signed_in?
    redirect_to signin_path
  end
end
```


