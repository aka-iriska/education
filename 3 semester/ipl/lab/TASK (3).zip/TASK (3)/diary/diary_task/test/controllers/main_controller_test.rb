require "test_helper"

class MainControllerTest < ActionDispatch::IntegrationTest
  test "should get menu" do
    get main_menu_url
    assert_response :success
  end

  test "should get adding" do
    get main_adding_url
    assert_response :success
  end

  test "should get calendar" do
    get main_calendar_url
    assert_response :success
  end

  test "should get settings" do
    get main_settings_url
    assert_response :success
  end
end
