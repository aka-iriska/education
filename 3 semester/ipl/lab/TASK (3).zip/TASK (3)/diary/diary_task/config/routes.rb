Rails.application.routes.draw do
  scope "(:locale)", locale: /en|ru/ do
  resources :notes
  resources :users
  resources :sessions, :only => [:new, :create, :destroy]
  match '/menu', to: 'main#menu', via: 'get'
  match '/settings', to: 'main#settings', via: 'get'
  match '/calendar', to: 'main#calendar', via: 'get'
  match '/main/adding/:id', to: 'main#adding', via: 'get'
  match '/main/diary/:id', to: 'main#diary', via: 'get'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html
  root 'main#menu'
  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  match '/adding', to: 'notes#new', via: [:get, :post]
  match '/signup', to: 'users#new', via: 'get'
  match '/signin', to: 'sessions#new', via: 'get'
  match '/set_locale', to: 'application#set_locale', via: 'get'
  match '/signout', to: 'sessions#destroy', via: 'delete'
  get "up" => "rails/health#show", as: :rails_health_check
  delete '/notes/:id'=> 'notes#destroy'
  end
  # Defines the root path route ("/")
  # root "posts#index"
end
