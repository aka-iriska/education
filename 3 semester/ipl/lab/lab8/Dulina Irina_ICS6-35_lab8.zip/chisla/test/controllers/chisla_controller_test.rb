require "test_helper"

class ChislaControllerTest < ActionDispatch::IntegrationTest
  test "should get input" do
    get chisla_input_url
    assert_response :success
  end

  test "should get view" do
    get chisla_view_url
    assert_response :success
  end
  test "for error" do
    get chisla_view_url, params: { str: 'fgdf' }
    assert_equal assigns[:err], 'Что-то пошло не так'
  end
  test "for right" do
    get chisla_view_url, params: { str:'5 6 7 1 2 0 -1 2 5 6' }
    assert_equal assigns[:final], '-1 2 5 6'
  end
end
