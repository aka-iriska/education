class ChislaController < ApplicationController
  def input
  end

  def view
    begin
      res = params[:str].scan(/-?\d+(?:\.\d+)?/).map(&:to_i)
      raise StandardError if res.length < 10
      max = 0
      all = []
      solution = ''
      i = 0
      loop do
        posl, len, i = create_posl(i, res)
        all << posl.join(' ')
        if len > max
          max = len
          solution = posl.join(' ')
        end
        break if i >= res.length
      end
      result = []
      all.length.times do |j|
        if solution == all[j]
          str = '+'
        else
          str = ' '
        end
        if j == 0
          result << [res.join(' '), all[j], str]
        else
          result << [' ', all[j], str]
        end
      end
      @final = solution
      @solution = result
    rescue StandardError
      @err = 'Что-то пошло не так'
      @solution = []
      # Ignored
    end
  end

  def create_posl(i, res)
    len = 0
    posl = []
    loop do
      len += 1
      posl << res[i]
      break if i + 1 == res.length
      break if (res[i+1] <= res[i])
      i += 1
    end
    i+=1
    [posl, len, i]
  end
end
