# frozen_string_literal: true
def create(res)
  max = 0
  all = []
  i = 0
  solution=''
  loop do
    posl, len, i = create_posl(i, res)
    all << posl.join(' ')
    if len > max
      max = len
      solution = posl.join(' ')
    end
    break if i >= res.length
  end
  [all, solution]
end
def create_posl(i, res)
  len = 0
  posl = []
  loop do
    len += 1
    posl << res[i]
    break if i + 1 == res.length
    break if (res[i+1] <= res[i])
    i += 1
  end
  i+=1
  [posl, len, i]
end

#str=gets.chomp.split(' ')
pp create([1, 2, 1, 2, 3, 3, 4, 5, 6])